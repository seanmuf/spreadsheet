package edu.cs3500.spreadsheets;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import edu.cs3500.spreadsheets.controller.WorksheetController;
import edu.cs3500.spreadsheets.model.SheetBuilder;
import edu.cs3500.spreadsheets.model.Spreadsheet;
import edu.cs3500.spreadsheets.model.WorksheetModel;
import edu.cs3500.spreadsheets.model.WorksheetReader;
import edu.cs3500.spreadsheets.view.SpreadsheetGraphicalView;
import edu.cs3500.spreadsheets.view.WorksheetGraphicalView;
import edu.cs3500.spreadsheets.view.WorksheetTextualView;
import edu.cs3500.spreadsheets.view.WorksheetView;

/**
 * The main class for our program.
 */
public class BeyondGood {

  /**
   * The main entry point.
   *
   * @param args any command-line arguments
   */
  public static void main(String[] args) {
    if (args.length == 4 && args[2].equals("-eval")) {
      evalFromFile(args);
    } else if (args.length == 4 && args[2].equals("-save")) {
      saveToFile(args);
    } else if (args[args.length - 1].equals("-gui")) {
      gui(args);
    } else if (args[args.length - 1].equals("-edit")) {
      edit(args);
    } else {
      System.out.print("Malformed command line arguments");
    }
  }

  /*
  Opens an editable view of the given file; if no file is given than a blank editable view is
  opened.
  */
  private static void edit(String[] args) {
    if (args.length == 1) {
      WorksheetView view = new SpreadsheetGraphicalView();
      WorksheetController controller = new WorksheetController(new Spreadsheet());
      controller.setView(view);
      view.display();
    } else if (args.length == 3 && args[0].equals("-in")) {
      String fileName = args[1];
      try {
        Readable readable = new BufferedReader(new FileReader(fileName));
        WorksheetReader.WorksheetBuilder<WorksheetModel> builder = new SheetBuilder();
        WorksheetModel sheet = WorksheetReader.read(builder, readable);
        WorksheetView view = new SpreadsheetGraphicalView();
        WorksheetController controller = new WorksheetController(sheet);
        controller.setView(view);
        view.display();
      } catch (IOException e) {
        System.out.print("File Not Found");
      }
    }
  }

  /*
  Opens a non-editable view of the given file; if no file is given, then a blank, non-editable view
  is displayed.
  */
  private static void gui(String[] args) {
    if (args.length == 1) {
      WorksheetView view = new WorksheetGraphicalView(new HashMap<>());
      view.display();
    } else if (args.length == 3 && args[0].equals("-in")) {
      String fileName = args[1];
      try {
        Readable readable = new BufferedReader(new FileReader(fileName));
        WorksheetReader.WorksheetBuilder<WorksheetModel> builder = new SheetBuilder();
        WorksheetModel sheet = WorksheetReader.read(builder, readable);
        WorksheetView view = new WorksheetGraphicalView(sheet.getAllCellValues());
        view.display();
      } catch (IOException e) {
        System.out.print("File Not Found");
      }
    }
  }

  //saves the spreadsheet file to a specified file.
  private static void saveToFile(String[] args) {
    if (!args[0].equals("-in")) {
      System.out.print("Malformed command line arguments");
    } else {
      String fileFromName = args[1];
      String fileToName = args[3];
      try {
        Readable readable = new BufferedReader(new FileReader(fileFromName));
        WorksheetReader.WorksheetBuilder<WorksheetModel> builder1 = new SheetBuilder();
        WorksheetModel model = WorksheetReader.read(builder1, readable);
        PrintWriter pw = new PrintWriter(fileToName);
        WorksheetView view = new WorksheetTextualView(model, pw);
        view.display();
        pw.close();
      } catch (IOException e) {
        System.out.print("Invalid file name");
      }
    }
  }

  //evaluates the specified cell in the given file.
  private static void evalFromFile(String[] args) {
    if (!args[0].equals("-in")) {
      System.out.print("Malformed command line arguments");
    } else {
      String fileName = args[1];
      String cell = args[3];
      try {
        Readable readable = new BufferedReader(new FileReader(fileName));
        WorksheetReader.WorksheetBuilder<WorksheetModel> builder = new SheetBuilder();
        WorksheetModel sheet = WorksheetReader.read(builder, readable);
        Object cellValue = sheet.getCellValue(cell);
        String cellString = cellValue.toString();
        try {
          Double d = Double.parseDouble(cellString);
          System.out.print(String.format("%f", d));
        } catch (NumberFormatException e) {
          if (cellString.equals("true") || cellString.equals("false")) {
            System.out.print(cellString);
          } else {
            System.out.print("\"" + addSlashes(cellString) + "\"");
          }
        }
      } catch (FileNotFoundException e) {
        System.out.print("File Not Found");
      }
    }
  }

  // adds slash character to string in front of double quotes and slashes
  private static String addSlashes(String cellString) {
    StringBuilder temp = new StringBuilder();
    for (int i = 0; i < cellString.length(); i++) {
      char c = cellString.charAt(i);
      if (c == '\"' || c == '\\') {
        temp.append("\\").append(c);
      } else {
        temp.append(c);
      }
    }
    return temp.toString();
  }
}
