package edu.cs3500.spreadsheets.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.SheetBuilder;
import edu.cs3500.spreadsheets.model.WorksheetModel;
import edu.cs3500.spreadsheets.model.WorksheetReader;
import edu.cs3500.spreadsheets.view.WorksheetTextualView;
import edu.cs3500.spreadsheets.view.WorksheetView;

/**
 * A controller that allows for the editing of a Spreadsheet model and the corresponding
 * SpreadsheetGraphicalView display.
 * It provides the following features: adding cell, changing cells, deleting cells, saving
 * Spreadsheets, and loading Spreadsheets.
 */
public class WorksheetController implements Features {

  private WorksheetModel model;
  private WorksheetView view;

  /**
   * Constructs a WorksheetController for the given WorksheetModel.
   *
   * @param model the given WorksheetModel.
   */
  public WorksheetController(WorksheetModel model) {
    this.model = model;
  }

  @Override
  public void setView(WorksheetView v) {
    view = v;
    view.addFeatures(this);
    for (Coord c : model.getAllValidCoords()) {
      try {
        view.updateView(c.toString(), model.getCellValue(c.toString()).toString());
      } catch (IllegalStateException e) {
        view.updateView(c.toString(), "#ERROR");
      }
      view.updateView(c.toString(), model.getRawCellValue(c.toString()));
    }
  }

  @Override
  public void addCell(String cell, Object value) {
    if (model.getAllValidCoords().contains(cellParse(cell))) {
      changeCell(cell, value);
    } else {
      try {
        model.addCell(cell, value);
        view.updateView(cell, model.getCellValue(cell).toString());
        view.updateView(cell, model.getRawCellValue(cell));
      } catch (IllegalStateException e) {
        view.updateView(cell, "#ERROR");
      }
    }
  }

  @Override
  public void changeCell(String cell, Object value) {
    try {
      model.changeCellValue(cell, value);
      for (Coord c : model.getAllValidCoords()) {
        view.updateView(c.toString(), model.getCellValue(c.toString()).toString());
        view.updateView(c.toString(), model.getRawCellValue(c.toString()));
      }
    } catch (IllegalStateException e) {
      view.updateView(cell, "#ERROR");
    }
  }

  @Override
  public void save(String fileName) {
    try {
      PrintWriter pw = new PrintWriter(fileName);
      WorksheetView view = new WorksheetTextualView(model, pw);
      view.display();
      pw.close();
    } catch (IOException e) {
      System.out.print("Invalid file name");
    }
  }

  @Override
  public void load(String fileName) {
    try {
      Readable readable = new BufferedReader(new FileReader(fileName));
      WorksheetReader.WorksheetBuilder<WorksheetModel> builder = new SheetBuilder();
      this.model = WorksheetReader.read(builder, readable);
      setView(view);
      view.display();
    } catch (IOException e) {
      System.out.print("File Not Found");
    }
  }

  @Override
  public void deleteCell(String cell) {
    this.changeCell(cell, "");
  }

  //Turns a string into a Coord for a cell.
  private static Coord cellParse(String cell) {
    if (!cell.matches("([A-Z])*\\d+")) {
      throw new IllegalArgumentException("Incorrect cell coordinate");
    } else {
      String[] s = cell.split("(?<=[A-Z])(?=[0-9])");
      return new Coord(Coord.colNameToIndex(s[0]), Integer.parseInt(s[1]));
    }
  }
}
