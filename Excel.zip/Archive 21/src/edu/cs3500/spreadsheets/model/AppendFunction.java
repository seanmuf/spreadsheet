package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.List;

/**
 * A FunctionObject that appends String cell values.
 */
class AppendFunction extends FunctionObject {

  @Override
  public String getValue(List<Formula> formulas) {
    String s = "";
    for (Formula f : formulas) {
      s += f.accept(new AppendVisitor());
    }
    return s;
  }

  @Override
  public <R> R accept(FormulaVisitor<R> visitor) {
    return visitor.visitFunctionObject(this);
  }

  @Override
  public List<Cell> getAllReferenced(Cell cell) {
    return new ArrayList<>();
  }

  @Override
  public String toString() {
    return "APPEND";
  }
}
