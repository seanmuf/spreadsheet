package edu.cs3500.spreadsheets.model;

import java.util.List;

/**
 * A visitor for values in a AppendFunction.
 */
class AppendVisitor implements FormulaVisitor<String> {

  @Override
  public String visitReference(Reference reference) {
    return appendAll(reference.getAllReferenced(new Cell(null, null,
            new Coord(0, 0))));
  }

  //Appends the StringValues in the given list of cells.
  private String appendAll(List<Cell> cells) {
    String out = "";
    for (Cell c : cells) {
      try {
        Double.parseDouble(c.getValue());
      } catch (NumberFormatException ignore) {
        if (!c.getValue().equals("true") && !c.getValue().equals("false")) {
          out += c.getValue();
        }
      }
    }
    return out;
  }

  @Override
  public String visitString(String value) {
    return value;
  }

  @Override
  public String visitDouble(Double value) {
    return "";
  }

  @Override
  public String visitBoolean(Boolean value) {
    return "";
  }

  @Override
  public String visitFunction(Function function) {
    return "";
  }

  @Override
  public String visitFunctionObject(FunctionObject functionObject) {
    return "";
  }
}
