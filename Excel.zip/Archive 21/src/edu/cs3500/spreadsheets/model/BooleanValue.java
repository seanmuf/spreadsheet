package edu.cs3500.spreadsheets.model;

import java.util.List;

/**
 * Represents a Boolean value inside a Cell.
 */
class BooleanValue extends Value {

  private final Boolean value;

  /**
   * Constructs a BooleanValue.
   *
   * @param value the value inside the BooleanValue.
   */
  BooleanValue(Boolean value) {
    this.value = value;
  }

  @Override
  public String getValue(List<Formula> formulas) {
    return value.toString();
  }

  @Override
  public <R> R accept(FormulaVisitor<R> visitor) {
    return visitor.visitBoolean(this.value);
  }

  @Override
  public String toString() {
    return String.valueOf(this.value);
  }
}
