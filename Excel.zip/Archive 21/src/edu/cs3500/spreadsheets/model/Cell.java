package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import edu.cs3500.spreadsheets.sexp.Parser;
import edu.cs3500.spreadsheets.sexp.Sexp;

/**
 * Represents a cell in a spreadsheet.
 */
class Cell {

  private Object value;
  private Formula formula;
  private final Coord coord;

  private boolean referencesComputed;

  /**
   * Constructs a Cell.
   * @param value the value the cell contains.
   * @param formula the formula the cell contains.
   * @param coord the coordinate of the cell.
   */
  Cell(Object value, Formula formula, Coord coord) {
    this.value = value;
    this.formula = formula;
    this.coord = coord;
  }

  /**
   * Obtains the value or formula of this Cell.
   *
   * @return the value or formula as a String.
   */
  String getValue() {
    if (!acyclic()) {
      throw new IllegalStateException("Cyclic references");
    } else if (formula == null && value == null) {
      return "";
    } else if (value != null) {
      return value.toString();
    } else {
      value = formula.getValue(new ArrayList<>());
    }
    return value.toString();
  }

  /**
   * The raw value of this cell, either a function or a value, as a String.
   * @return the string denoting the raw value.
   */
  public String getRawValue() {
    if (formula == null) {
      return value.toString();
    } else {
      return "=" + formula.toString();
    }
  }

  /**
   * Checks if the Cell formula contains a circular reference.
   *
   * @return either true or false based on the result.
   */
  boolean acyclic() {
    if (formula == null) {
      return true;
    } else {
      return formula.accept(new CycleVisitor(this));
    }
  }

  /**
   * Obtains the cells being referenced by this Cell.
   *
   * @return the list of referenced cells.
   */
  List<Cell> getReferencedCells(Cell cell) {
    if (referencesComputed || this.equals(cell) || formula == null) {
      return new ArrayList<>();
    } else {
      referencesComputed = true;
      return formula.getAllReferenced(cell);
    }
  }

  /**
   * Updates the value of this cell.
   *
   * @param contents the new value of the cell.
   * @param sheet the updated Spreadsheet.
   */
  void updateValue(String contents, Map<Coord, Cell> sheet) {
    try {
      double value = Double.parseDouble(contents);
      this.value = value;
      this.formula = null;
    } catch (NumberFormatException ignored) {
      /**
       * Ignore the error and check other value types.
       */
    }
    if (contents.equals("true") || contents.equals("false")) {
      boolean value = Boolean.parseBoolean(contents);
      this.value = value;
      this.formula = null;
    } else if (contents.length() == 0) {
      this.value = contents;
      this.formula = null;
    }
    else if (contents.charAt(0) == '=') {
      Sexp sexp = Parser.parse(contents.substring(1));
      Formula formula = sexp.accept(new FormulaCreator(sheet));
      this.formula = formula;
      this.value = null;
    } else {
      this.value = contents;
      this.formula = null;
    }
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Cell c = (Cell) o;
    return this.coord.equals(c.coord);
  }

  @Override
  public String toString() {
    return this.coord.toString();
  }

  @Override
  public int hashCode() {
    return Objects.hash(coord.row, coord.col);
  }

  /**
   * Changes a Cell computed status to false.
   */
  void revertToUnchecked() {
    referencesComputed = false;
  }

  public void recompute() {
    if (formula != null) {
      value = formula.getValue(new ArrayList<>());
    }
  }
}
