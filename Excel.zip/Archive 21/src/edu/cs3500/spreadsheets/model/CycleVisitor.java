package edu.cs3500.spreadsheets.model;

import java.util.List;

/**
 * A visitor that determines if any cycles exist in a Spreadsheet.
 */
class CycleVisitor implements FormulaVisitor<Boolean> {

  private final Cell cell;

  /**
   * Constructs a CycleVisitor.
   *
   * @param cell the parent cell of the cycle.
   */
  CycleVisitor(Cell cell) {
    this.cell = cell;
  }

  @Override
  public Boolean visitReference(Reference reference) {
    return visitReferenceFormulas(reference);
  }

  @Override
  public Boolean visitString(String value) {
    return false;
  }

  @Override
  public Boolean visitDouble(Double value) {
    return false;
  }

  @Override
  public Boolean visitBoolean(Boolean value) {
    return false;
  }

  @Override
  public Boolean visitFunction(Function function) {
    return visitReferenceFormulas(function);
  }

  //Helper to visit References and Functions.
  private Boolean visitReferenceFormulas(Formula function) {
    List<Cell> cells = function.getAllReferenced(this.cell);
    for (Cell c : cells) {
      if (c.getReferencedCells(this.cell).contains(this.cell)) {
        return false;
      } else if (c.equals(cell)) {
        return false;
      }
    }
    return true;
  }

  @Override
  public Boolean visitFunctionObject(FunctionObject functionObject) {
    return false;
  }
}
