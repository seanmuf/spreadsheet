package edu.cs3500.spreadsheets.model;

import java.util.List;

/**
 * Represents a Double value inside a Cell.
 */
class DoubleValue extends Value {

  private final Double value;

  /**
   * Constructs a DoubleValue.
   *
   * @param value the value inside the DoubleValue.
   */
  DoubleValue(Double value) {
    this.value = value;
  }

  @Override
  public String getValue(List formulas) {
    return value.toString();
  }

  @Override
  public <R> R accept(FormulaVisitor<R> visitor) {
    return visitor.visitDouble(this.value);
  }

  @Override
  public String toString() {
    return Double.toString(this.value);
  }
}
