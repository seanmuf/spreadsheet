package edu.cs3500.spreadsheets.model;

import java.util.List;

/**
 * Represents the possible values a Formula can be in a Cell.
 */
interface Formula {

  /**
   * Obtains the value of the formulas in the list of formulas given.
   *
   * @param formulas the list of formulas.
   * @return the values of the formulas as a String.
   */
  String getValue(List<Formula> formulas);

  /**
   * Determines if this object is a FunctionObject.
   *
   * @return a boolean based on the result.
   */
  boolean isFunctionObject();

  /**
   * Accepts a FormulaVisitor.
   *
   * @param visitor the visitor.
   * @param <R> the return type indicated.
   * @return the type R.
   */
  <R> R accept(FormulaVisitor<R> visitor);

  /**
   * Gets all the cells being referenced in a Formula.
   *
   * @return the list of referenced cells.
   */
  List<Cell> getAllReferenced(Cell cell);
}
