package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import edu.cs3500.spreadsheets.sexp.Sexp;
import edu.cs3500.spreadsheets.sexp.SexpVisitor;

/**
 * Creates the given Formula.
 */
class FormulaCreator implements SexpVisitor<Formula> {

  private final Map<Coord, Cell> sheet;

  /**
   * Constructs a FormulaCreator.
   *
   * @param sheet the Spreadsheet.
   */
  FormulaCreator(Map<Coord, Cell> sheet) {
    this.sheet = sheet;
  }

  @Override
  public Formula visitBoolean(boolean b) {
    return new BooleanValue(b);
  }

  @Override
  public Formula visitNumber(double d) {
    return new DoubleValue(d);
  }

  @Override
  public Formula visitSList(List<Sexp> l) {
    List<Formula> formulas = listFormulas(l);
    return new Function(formulas);
  }

  private List<Formula> listFormulas(List<Sexp> l) {
    List<Formula> formulas = new ArrayList<>();
    for (Sexp sexp : l) {
      formulas.add(sexp.accept(this));
    }
    return formulas;
  }

  @Override
  public Formula visitSymbol(String s) {
    if (s.equals("SUM")) {
      return new SumFunction();
    } else if (s.equals("PRODUCT")) {
      return new ProductFunction();
    } else if (s.equals("<")) {
      return new LessThanFunction();
    } else if (s.equals("APPEND")) {
      return new AppendFunction();
    } else if (s.matches("([A-Z])*\\d+")) {
      String[] strings = s.split("(?<=[A-Z])(?=[0-9])");
      Integer col = Coord.colNameToIndex(strings[0]);
      Integer row = Integer.parseInt(strings[1]);
      Coord coord = new Coord(col, row);
      if (!sheet.containsKey(coord)) {
        sheet.put(coord, new Cell(null, null, coord));
      }
      Cell c = sheet.get(coord);
      return new Reference(new ArrayList<>(Collections.singleton(c)));
    } else if (s.matches("([A-Z])*\\d:([A-Z])*\\d")) {
      String[] strings = s.split(":");
      String startCell = strings[0];
      String endCell = strings[1];
      return new Reference(toCellList(startCell, endCell));
    } else {
      throw new IllegalArgumentException("Invalid Function or Cell Name");
    }
  }

  private List<Cell> toCellList(String startCell, String endCell) {
    String[] start = startCell.split("(?<=[A-Z])(?=[0-9])");
    String[] end = endCell.split("(?<=[A-Z])(?=[0-9])");
    int startCol = Coord.colNameToIndex(start[0]);
    int startRow = Integer.parseInt(start[1]);
    int endCol = Coord.colNameToIndex(end[0]);
    int endRow = Integer.parseInt(end[1]);
    List<Cell> cells = new ArrayList<>();
    for (int i = startCol; i <= endCol; i++) {
      for (int j = startRow; j <= endRow; j++) {
        Coord coord = new Coord(i, j);
        if (!sheet.containsKey(coord)) {
          sheet.put(coord, new Cell(null, null, coord));
        }
        cells.add(sheet.get(coord));
      }
    }
    return cells;
  }

  @Override
  public Formula visitString(String s) {
    return new StringValue(s);
  }
}
