package edu.cs3500.spreadsheets.model;


/**
 * A visitor for the possible Formula values.
 *
 * @param <R> the return type.
 */
interface FormulaVisitor<R> {

  /**
   * Visits a Reference.
   *
   * @param reference the Reference being visited.
   * @return the return type R indicated.
   */
  R visitReference(Reference reference);

  /**
   * Visits a String.
   *
   * @param value the Reference being visited.
   * @return the return type R indicated.
   */
  R visitString(String value);

  /**
   * Visits a Double.
   *
   * @param value the Reference being visited.
   * @return the return type R indicated.
   */
  R visitDouble(Double value);

  /**
   * Visits a Boolean.
   *
   * @param value the Boolean being visited.
   * @return the return type R indicated.
   */
  R visitBoolean(Boolean value);

  /**
   * Visits a Function.
   *
   * @param function the Function being visited.
   * @return the return type R indicated.
   */
  R visitFunction(Function function);

  /**
   * Visits a Reference.
   *
   * @param functionObject the FunctionObject being visited.
   * @return the return type R indicated.
   */
  R visitFunctionObject(FunctionObject functionObject);
}
