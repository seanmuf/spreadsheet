package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents functions that can be used to evaluate cells.
 */
class Function implements Formula {

  private final List<Formula> formulas;

  /**
   * Constructs a Function.
   *
   * @param formulas the values inside the Function.
   */
  Function(List<Formula> formulas) {
    this.formulas = formulas;
  }

  @Override
  public String getValue(List<Formula> list) {
    if (formulas.isEmpty()) {
      return " ";
    }
    Formula f = formulas.get(0);
    if (f.isFunctionObject()) {
      return f.getValue((formulas));
    } else {
      if (f.getValue(new ArrayList<>()).equals("")) {
        return " ";
      } else {
        return f.getValue(new ArrayList<>());
      }
    }
  }

  @Override
  public boolean isFunctionObject() {
    return false;
  }

  @Override
  public <R> R accept(FormulaVisitor<R> visitor) {
    return visitor.visitFunction(this);
  }

  @Override
  public List<Cell> getAllReferenced(Cell cell) {
    List<Cell> cells = new ArrayList<>();
    for (Formula f : formulas) {
      cells.addAll(f.getAllReferenced(cell));
    }
    return cells;
  }

  @Override
  public String toString() {
    String s = "";
    for (int i = 0; i < formulas.size(); i++) {
      if (i == formulas.size() - 1) {
        s += formulas.get(i).toString();
      } else {
        s += formulas.get(i).toString() + " ";
      }
    }
    return "(" + s + ")";
  }
}
