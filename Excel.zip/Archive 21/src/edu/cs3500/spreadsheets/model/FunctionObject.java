package edu.cs3500.spreadsheets.model;

/**
 * Represents a FunctionObject on a Formula.
 */
abstract class FunctionObject implements Formula {

  @Override
  public boolean isFunctionObject() {
    return true;
  }
}
