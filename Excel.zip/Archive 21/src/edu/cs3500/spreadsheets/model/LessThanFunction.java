package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.List;

/**
 * A FunctionObject that compares two cell values.
 */
class LessThanFunction extends FunctionObject {

  @Override
  public String getValue(List<Formula> formulas) {
    if (formulas.size() != 3) {
      throw new IllegalArgumentException("Invalid Number of Arguments");
    }
    try {
      Double first = Double.parseDouble(formulas.get(1).getValue(new ArrayList<>()));
      Double second = Double.parseDouble(formulas.get(2).getValue(new ArrayList<>()));
      return Boolean.toString(first < second);
    } catch (NumberFormatException e) {
      throw new IllegalArgumentException("Invalid Argument Type: only numbers");
    }
  }

  @Override
  public <R> R accept(FormulaVisitor<R> visitor) {
    return visitor.visitFunctionObject(this);
  }

  @Override
  public List<Cell> getAllReferenced(Cell cell) {
    return new ArrayList<>();
  }

  @Override
  public String toString() {
    return "<";
  }
}
