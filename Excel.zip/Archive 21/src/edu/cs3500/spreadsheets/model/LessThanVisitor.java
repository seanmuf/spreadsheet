package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;

/**
 * A visitor class for values in a LessThanFunction.
 */
class LessThanVisitor implements FormulaVisitor<Double> {

  @Override
  public Double visitReference(Reference reference) {
    if (reference.getAllReferenced(new Cell(null,
            null, new Coord(0, 0))).size() == 1) {
      try {
        Double d = Double.parseDouble(reference.getValue(new ArrayList<>()));
        return d;
      } catch (NumberFormatException e) {
        throw new IllegalArgumentException("Invalid Reference Type");
      }
    } else {
      throw new IllegalArgumentException("Invalid Reference Size");
    }
  }

  @Override
  public Double visitString(String value) {
    throw new IllegalArgumentException("Invalid Input Type");
  }

  @Override
  public Double visitDouble(Double value) {
    return value;
  }

  @Override
  public Double visitBoolean(Boolean value) {
    throw new IllegalArgumentException("Invalid Input Type");
  }

  @Override
  public Double visitFunction(Function function) {
    try {
      Double d = Double.parseDouble(function.getValue(new ArrayList<>()));
      return d;
    } catch (NumberFormatException e) {
      throw new IllegalArgumentException("Invalid Function Type");
    }
  }

  @Override
  public Double visitFunctionObject(FunctionObject function) {
    throw new IllegalArgumentException("Invalid Type");
  }

}
