package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.List;

/**
 * A FunctionObject that multiplies cell values.
 */
public class ProductFunction extends FunctionObject {

  @Override
  public String getValue(List<Formula> formulas) {
    if (noDoubleValues(formulas)) {
      return "0.0";
    } else {
      Double d = 1.0;
      for (Formula f : formulas) {
        d *= f.accept(new ProductVisitor());
      }
      return d.toString();
    }
  }

  //Determines if there are no doubles in the list of formulas.
  private boolean noDoubleValues(List<Formula> formulas) {
    for (Formula f : formulas) {
      try {
        Double.parseDouble(f.getValue(new ArrayList<>()));
        return false;
      } catch (NumberFormatException ignore) {
        /**
         * Ignore the exception and try keep searching for a double value.
         */
      }
    }
    return true;
  }

  @Override
  public <R> R accept(FormulaVisitor<R> visitor) {
    return visitor.visitFunctionObject(this);
  }

  @Override
  public List<Cell> getAllReferenced(Cell cell) {
    return new ArrayList<>();
  }

  @Override
  public String toString() {
    return "PRODUCT";
  }
}
