package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.List;

/**
 * A visitor class for values in a ProductFunction.
 */
class ProductVisitor implements FormulaVisitor<Double> {

  @Override
  public Double visitReference(Reference reference) {
    return multiplyAll(reference.getAllReferenced(new Cell(null, null,
            new Coord(0, 0))));
  }

  //Multiplies all the cell values in the given list of cells.
  private Double multiplyAll(List<Cell> cells) {
    boolean defaultTo0 = true;
    Double dub = 1.0;
    for (Cell c : cells) {
      try {
        Double d = Double.parseDouble(c.getValue());
        dub *= d;
        defaultTo0 = false;
      } catch (NumberFormatException ignored) {
      }
    }
    if (!defaultTo0) {
      return dub;
    } else {
      return 1.0;
    }
  }

  @Override
  public Double visitString(String value) {
    return 1.0;
  }

  @Override
  public Double visitDouble(Double value) {
    return value;
  }

  @Override
  public Double visitBoolean(Boolean value) {
    return 1.0;
  }

  @Override
  public Double visitFunction(Function function) {
    try {
      Double d = Double.parseDouble(function.getValue(new ArrayList<>()));
      return d;
    } catch (NumberFormatException e) {
      return 1.0;
    }
  }

  @Override
  public Double visitFunctionObject(FunctionObject function) {
    return 1.0;
  }

}
