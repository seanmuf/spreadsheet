package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a Reference inside a Cell.
 */
class Reference implements Formula {

  private final List<Cell> cells;

  /**
   * Constructs a Reference.
   *
   * @param cells the cells being referenced.
   */
  Reference(List<Cell> cells) {
    this.cells = cells;
  }

  @Override
  public String getValue(List formulas) {
    if (cells.size() == 1) {
      return cells.get(0).getValue();
    }
    return "";
  }

  @Override
  public boolean isFunctionObject() {
    return false;
  }

  @Override
  public <R> R accept(FormulaVisitor<R> visitor) {
    return visitor.visitReference(this);
  }

  @Override
  public List<Cell> getAllReferenced(Cell cell) {
    List<Cell> refCells = new ArrayList<>();
    for (Cell c : cells) {
      refCells.add(c);
      if (c.equals(cell)) {
        return refCells;
      }
      refCells.addAll(c.getReferencedCells(cell));
    }
    return refCells;
  }

  @Override
  public String toString() {
    if (cells.size() == 1) {
      return cells.get(0).toString();
    } else {
      return cells.get(0).toString() + ":" + cells.get(cells.size() - 1).toString();
    }
  }


}
