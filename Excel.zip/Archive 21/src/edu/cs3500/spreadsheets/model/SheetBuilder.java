package edu.cs3500.spreadsheets.model;

import java.util.AbstractMap;
import java.util.ArrayList;

import java.util.List;

/**
 * Builds a WorkSheetModel.
 */
public final class SheetBuilder implements WorksheetReader.WorksheetBuilder<WorksheetModel> {

  List<AbstractMap.SimpleEntry<Coord, String>> cells;

  /**
   * Constructs an empty SheetBuilder.
   */
  public SheetBuilder() {
    this.cells = new ArrayList<>();
  }

  @Override
  public WorksheetReader.WorksheetBuilder<WorksheetModel> createCell(int col, int row,
                                                                     String contents) {
    Coord coord = new Coord(col, row);
    AbstractMap.SimpleEntry<Coord, String>
            cell = new AbstractMap.SimpleEntry<>(coord, contents);
    cells.add(cell);
    return this;
  }

  @Override
  public WorksheetModel createWorksheet() {
    WorksheetModel sheet = new Spreadsheet();
    for (int i = 0; i < cells.size(); i++) {
      AbstractMap.SimpleEntry<Coord, String> cell = cells.get(i);
      sheet.addCell(Coord.colIndexToName(cell.getKey().col) + cell.getKey().row,
              cell.getValue());
    }
    return sheet;
  }
}