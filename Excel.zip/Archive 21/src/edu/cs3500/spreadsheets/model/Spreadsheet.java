package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.cs3500.spreadsheets.sexp.Parser;
import edu.cs3500.spreadsheets.sexp.Sexp;

/**
 * A basic spreadsheet than allows for the adding and evaluating of cells.
 */
public class Spreadsheet implements WorksheetModel {

  private final Map<Coord, Cell> sheet;

  /**
   * Constructs an empty spreadsheet.
   */
  public Spreadsheet() {
    this.sheet = new HashMap<>();
  }

  @Override
  public void addCell(String cell, Object value) {
    Coord coord = cellParse(cell);
    if (cellExists(coord)) {
      changeCellValue(cell, value);
    } else {
      Cell c = createCell(value.toString(), coord);
      sheet.put(coord, c);
    }
  }

  //Checks if there is a cell at the given Coord.
  private boolean cellExists(Coord coord) {
    if (sheet.isEmpty()) {
      return false;
    } else {
      return sheet.containsKey(coord);
    }
  }

  @Override
  public void changeCellValue(String cell, Object value) {
    try {
      Coord coord = cellParse(cell);
      Cell c = sheet.get(coord);
      c.updateValue(value.toString(), sheet);
      sheet.put(coord, c);
      uncheckCells();
      for (Cell cl : sheet.values()) {
        cl.recompute();
      }
    } catch (NullPointerException e) {
      throw new IllegalArgumentException("Cell Does Not Exist");
    }
  }

  @Override
  public Object getCellValue(String cell) {
    if (sheet.isEmpty()) {
      throw new IllegalStateException("The spreadsheet is empty");
    }
    Coord coord = cellParse(cell);
    if (!sheet.containsKey(coord)) {
      return "";
    }
    Cell c = sheet.get(coord);
    String s = c.getValue();
    try {
      double d = Double.parseDouble(s);
      return d;
    } catch (NumberFormatException e) {
      /**
       * Ignore the exception and try other data types.
       */
    }
    if (s.equals("true") || s.equals("false")) {
      return Boolean.parseBoolean(s);
    } else {
      return s;
    }
  }

  @Override
  public String getRawCellValue(String cell) {
    Coord coord = cellParse(cell);
    if (sheet.isEmpty()) {
      throw new IllegalStateException("The spreadsheet is empty");
    }
    if (!sheet.containsKey(coord)) {
      return "";
    } else {
      Cell c = sheet.get(coord);
      return c.getRawValue();
    }
  }

  @Override
  public List<Coord> getAllValidCoords() {
    List<Coord> coords = new ArrayList<>();
    for (Coord c : sheet.keySet()) {
      coords.add(c);
    }
    return coords;
  }

  @Override
  public Map<Coord, Object> getAllCellValues() {
    Map<Coord, Object> values = new HashMap<>();
    for (Coord c : sheet.keySet()) {
      values.put(c, getCellValue(c.toString()));
    }
    return values;
  }

  @Override
  public Map<Coord, String> getAllRawCellValues() {
    Map<Coord, String> values = new HashMap<>();
    for (Coord c : sheet.keySet()) {
      values.put(c, getRawCellValue(c.toString()));
    }
    return values;
  }

  //Resets memoization of cells after a value is changed.
  private void uncheckCells() {
    for (Cell c : sheet.values()) {
      c.revertToUnchecked();
    }
  }

  //Turns a string into a Coord for a cell.
  private static Coord cellParse(String cell) {
    if (!cell.matches("([A-Z])*\\d+")) {
      throw new IllegalArgumentException("Incorrect cell coordinate");
    } else {
      String[] s = cell.split("(?<=[A-Z])(?=[0-9])");
      return new Coord(Coord.colNameToIndex(s[0]), Integer.parseInt(s[1]));
    }
  }

  //Creates a cell based on the given contents and Coord.
  private Cell createCell(String contents, Coord coord) {
    try {
      double value = Double.parseDouble(contents);
      return new Cell(value, null, coord);
    } catch (NumberFormatException e) {
      /**
       * Ignore the exception and try other data types.
       */
    }
    if (contents.equals("true") || contents.equals("false")) {
      boolean value = Boolean.parseBoolean(contents);
      return new Cell(value, null, coord);
    } else if (contents.length() == 0) {
      return new Cell(contents, null, coord);
    } else if (contents.charAt(0) == '=') {
      Sexp sexp = Parser.parse(contents.substring(1));
      Formula formula = sexp.accept(new FormulaCreator(sheet));
      return new Cell(null, formula, coord);
    } else {
      return new Cell(contents, null, coord);
    }
  }
}
