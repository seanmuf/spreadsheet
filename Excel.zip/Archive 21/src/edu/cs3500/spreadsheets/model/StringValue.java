package edu.cs3500.spreadsheets.model;


import java.util.List;

/**
 * Represents a String value inside a Cell.
 */
class StringValue extends Value {

  private final String value;

  /**
   * Constructs a StringValue.
   *
   * @param value the value in the StringValue.
   */
  StringValue(String value) {
    this.value = value;
  }

  @Override
  public String getValue(List<Formula> formulas) {
    return value;
  }

  @Override
  public <R> R accept(FormulaVisitor<R> visitor) {
    return visitor.visitString(this.value);
  }

  @Override
  public String toString() {
    return this.value;
  }
}
