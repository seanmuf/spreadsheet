package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.List;

/**
 * A FunctionObject that sums cell values.
 */
class SumFunction extends FunctionObject {

  @Override
  public String getValue(List<Formula> formulas) {
    Double d = 0.0;
    for (Formula f : formulas) {
      d += f.accept(new SumVisitor());
    }
    return d.toString();
  }

  @Override
  public <R> R accept(FormulaVisitor<R> visitor) {
    return visitor.visitFunctionObject(this);
  }

  @Override
  public List<Cell> getAllReferenced(Cell cell) {
    return new ArrayList<>();
  }

  @Override
  public String toString() {
    return "SUM";
  }
}
