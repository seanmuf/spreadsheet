package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.List;

/**
 * A visitor class for values in a SumFunction.
 */
class SumVisitor implements FormulaVisitor<Double> {

  @Override
  public Double visitReference(Reference reference) {
    return addAll(reference.getAllReferenced(new Cell(null, null,
            new Coord(0, 0))));
  }

  //Adds all the cell values in the list of cells given.
  private Double addAll(List<Cell> cells) {
    Double dub = 0.0;
    for (Cell c : cells) {
      try {
        Double d = Double.parseDouble(c.getValue());
        dub += d;
      } catch (NumberFormatException e) {
        /**
         * Ignore the exception and continue searching for a double value.
         */
      }
    }
    return dub;
  }

  @Override
  public Double visitString(String value) {
    return 0.0;
  }

  @Override
  public Double visitDouble(Double value) {
    return value;
  }

  @Override
  public Double visitBoolean(Boolean value) {
    return 0.0;
  }

  @Override
  public Double visitFunction(Function function) {
    try {
      Double d = Double.parseDouble(function.getValue(new ArrayList<>()));
      return d;
    } catch (NumberFormatException e) {
      return 0.0;
    }
  }

  @Override
  public Double visitFunctionObject(FunctionObject function) {
    return 0.0;
  }

}
