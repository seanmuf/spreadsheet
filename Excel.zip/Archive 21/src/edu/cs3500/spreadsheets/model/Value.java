package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;
import java.util.List;

/**
 * An abstract class denoting a Formula that is just a value.
 */
abstract class Value implements Formula {

  @Override
  public boolean isFunctionObject() {
    return false;
  }

  @Override
  public List<Cell> getAllReferenced(Cell cell) {
    return new ArrayList<>();
  }
}
