package edu.cs3500.spreadsheets.view;

import java.io.IOException;
import edu.cs3500.spreadsheets.controller.Features;
import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.WorksheetModel;

/**
 * A WorksheetView that appends the model string to an Appendable to be used for saving to a file.
 */
public class WorksheetTextualView implements WorksheetView {

  private final WorksheetModel model;
  private final Appendable ap;

  /**
   * Constructor for a WorksheetTextualView.
   *
   * @param model the model to be viewed
   * @param ap    the appendable to append to
   */
  public WorksheetTextualView(WorksheetModel model, Appendable ap) {
    this.model = model;
    this.ap = ap;
  }

  @Override
  public void display() {
    try {
      ap.append(modelToString());
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  @Override
  public void updateView(String cell, String value) {
    try {
      ap.append(cell + " " + value + "\n");
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  @Override
  public void addFeatures(Features features) {
    /**
     * This doesn't really mean anything for the textual view.
     */
  }

  @Override
  public Coord getSelectedCell() {
    return new Coord(1, 1);
  }

  // produce a String that represents the model
  private String modelToString() {
    StringBuilder modelString = new StringBuilder();
    for (Coord c : model.getAllValidCoords()) {
      modelString.append(c.toString()).append(" ").append(model.getRawCellValue(c.toString()))
          .append("\n");
    }
    return modelString.toString();
  }
}
