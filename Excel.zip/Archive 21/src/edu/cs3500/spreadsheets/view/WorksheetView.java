package edu.cs3500.spreadsheets.view;

import edu.cs3500.spreadsheets.controller.Features;
import edu.cs3500.spreadsheets.model.Coord;

/**
 * An interface to view a WorksheetModel.
 */
public interface WorksheetView {

  /**
   * Display the view.
   */
  void display();

  /**
   * Update the view after an action has been performed.
   */
  void updateView(String cell, String value);

  /**
   * Add features to the view.
   *
   * @param features the features to be added
   */
  void addFeatures(Features features);

  /**
   * Get the currently selected cell's Coord.
   */
  Coord getSelectedCell();
}
