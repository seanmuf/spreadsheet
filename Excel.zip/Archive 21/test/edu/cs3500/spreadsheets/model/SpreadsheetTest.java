package edu.cs3500.spreadsheets.model;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Tests for Spreadsheet and its functionality.
 */
public class SpreadsheetTest {

  WorksheetModel spreadsheet = new Spreadsheet();

  @Test
  public void testEmptySpreadsheet() {
    try {
      spreadsheet.getCellValue("A1");
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), "The spreadsheet is empty");
    }
  }

  @Test
  public void testAddCell() {
    spreadsheet.addCell("A1", "dog");
    spreadsheet.addCell("B3", 3);
    spreadsheet.addCell("A2", true);
    assertEquals(spreadsheet.getCellValue("A1"), "dog");
    assertEquals(spreadsheet.getCellValue("B3"), 3.0);
    assertEquals(spreadsheet.getCellValue("A2"), true);
  }

  @Test
  public void testGetStringValue() {
    spreadsheet.addCell("A1", "dog");
    assertEquals(spreadsheet.getCellValue("A1"), "dog");
  }

  @Test
  public void testGetDoubleValue() {
    spreadsheet.addCell("A1", 3);
    assertEquals(spreadsheet.getCellValue("A1"), 3.0);
  }

  @Test
  public void testGetBooleanValue() {
    spreadsheet.addCell("A1", false);
    assertEquals(spreadsheet.getCellValue("A1"), false);
  }

  @Test
  public void testGetEmptyCellValue() {
    spreadsheet.addCell("A1", "dog");
    spreadsheet.addCell("B3", 3);
    spreadsheet.addCell("A2", true);
    assertEquals(spreadsheet.getCellValue("A4"), "");
  }

  @Test
  public void testChangeExistingCell() {
    spreadsheet.addCell("A1", "dog");
    assertEquals(spreadsheet.getCellValue("A1"), "dog");
    spreadsheet.changeCellValue("A1", "true");
    assertEquals(spreadsheet.getCellValue("A1"), true);
  }

  @Test
  public void testAppend() {
    spreadsheet.addCell("A1", "Sean");
    spreadsheet.addCell("B1", "cute");
    spreadsheet.addCell("A2", " is ");
    spreadsheet.addCell("B4", "=(APPEND A1:B2)");
    assertEquals(spreadsheet.getCellValue("B4"), "Sean is cute");
  }

  @Test
  public void testAppendInvalidTypeBoolean() {
    spreadsheet.addCell("A1", "Sean");
    spreadsheet.addCell("B1", false);
    spreadsheet.addCell("A2", " is ");
    spreadsheet.addCell("B4", "=(APPEND A1:B2)");
    assertEquals(spreadsheet.getCellValue("B4"), "Sean is ");
  }

  @Test
  public void testAppendInvalidTypeDouble() {
    spreadsheet.addCell("A1", "Sean");
    spreadsheet.addCell("B1", " cute");
    spreadsheet.addCell("A2", 13.0);
    spreadsheet.addCell("B4", "=(APPEND A1:B2)");
    assertEquals(spreadsheet.getCellValue("B4"), "Sean cute");
  }

  @Test
  public void testAppendRegion() {
    spreadsheet.addCell("B1", "cat");
    spreadsheet.addCell("B2", 3);
    spreadsheet.addCell("B3", "cat");
    spreadsheet.addCell("C1", "dog");
    spreadsheet.addCell("C2", true);
    spreadsheet.addCell("C3", 2);
    spreadsheet.addCell("A1", "=(APPEND B1:C3)");
    assertEquals(spreadsheet.getCellValue("A1"), "catcatdog");
  }

  @Test
  public void testAppendSameCell() {
    spreadsheet.addCell("A1", "Sean");
    spreadsheet.addCell("B2", "=(APPEND A1 A1)");
    assertEquals(spreadsheet.getCellValue("B2"), "SeanSean");
  }

  @Test
  public void testSum() {
    spreadsheet.addCell("A1", 6);
    spreadsheet.addCell("B1", 4);
    spreadsheet.addCell("A2", "=(SUM A1:B1)");
    assertEquals(spreadsheet.getCellValue("A2"), 10.0);
  }

  @Test
  public void testSumInvalidTypeBoolean() {
    spreadsheet.addCell("A1", 6);
    spreadsheet.addCell("B1", true);
    spreadsheet.addCell("A2", "=(SUM A1:B1)");
    assertEquals(spreadsheet.getCellValue("A2"), 6.0);
  }

  @Test
  public void testSumInvalidTypeString() {
    spreadsheet.addCell("A1", 7);
    spreadsheet.addCell("B1", "cat");
    spreadsheet.addCell("A2", "=(SUM A1:B1)");
    assertEquals(spreadsheet.getCellValue("A2"), 7.0);
  }

  @Test
  public void testSumRegion() {
    spreadsheet.addCell("B1", 2);
    spreadsheet.addCell("B2", 3);
    spreadsheet.addCell("B3", "cat");
    spreadsheet.addCell("C1", 7);
    spreadsheet.addCell("C2", true);
    spreadsheet.addCell("C3", 2);
    spreadsheet.addCell("A1", "=(SUM B1:C3)");
    assertEquals(spreadsheet.getCellValue("A1"), 14.0);
  }

  @Test
  public void testSumSameCell() {
    spreadsheet.addCell("B1", 5);
    spreadsheet.addCell("C1", 7);
    spreadsheet.addCell("A1", "=(SUM B1 B1)");
    spreadsheet.addCell("A2", "=(SUM (SUM B1 B1) (SUM C1 C1))");
    assertEquals(spreadsheet.getCellValue("A1"), 10.0);
    assertEquals(spreadsheet.getCellValue("A2"), 24.0);
  }

  @Test
  public void testProduct() {
    spreadsheet.addCell("A1", 5);
    spreadsheet.addCell("B1", 3);
    spreadsheet.addCell("B2", 2);
    spreadsheet.addCell("A2", "=(PRODUCT A1:B1)");
    spreadsheet.addCell("A3", "=(PRODUCT (PRODUCT A1:B1) B2)");
    spreadsheet.addCell("A4", "=(PRODUCT (SUM A1:B1) B2)");
    assertEquals(spreadsheet.getCellValue("A2"), 15.0);
    assertEquals(spreadsheet.getCellValue("A3"), 30.0);
    assertEquals(spreadsheet.getCellValue("A4"), 16.0);
  }

  @Test
  public void testProductInvalidTypeBoolean() {
    spreadsheet.addCell("A1", 6);
    spreadsheet.addCell("B1", true);
    spreadsheet.addCell("B3", 2);
    spreadsheet.addCell("A2", "=(PRODUCT A1:B1 B3)");
    assertEquals(spreadsheet.getCellValue("A2"), 12.0);
  }

  @Test
  public void testProductInvalidTypeString() {
    spreadsheet.addCell("A1", 7);
    spreadsheet.addCell("B1", "cat");
    spreadsheet.addCell("A2", "=(PRODUCT A1:B1)");
    assertEquals(spreadsheet.getCellValue("A2"), 7.0);
  }

  @Test
  public void testProductRegion() {
    spreadsheet.addCell("B1", 2);
    spreadsheet.addCell("B2", 5);
    spreadsheet.addCell("B3", "cat");
    spreadsheet.addCell("C1", 2);
    spreadsheet.addCell("C2", true);
    spreadsheet.addCell("C3", 3);
    spreadsheet.addCell("A1", "=(PRODUCT B1:C3)");
    assertEquals(spreadsheet.getCellValue("A1"), 60.0);
  }

  @Test
  public void testProductSameCell() {
    spreadsheet.addCell("B1", 2);
    spreadsheet.addCell("C1", 3);
    spreadsheet.addCell("A1", "=(PRODUCT B1 B1)");
    spreadsheet.addCell("A2", "=(PRODUCT (PRODUCT B1 B1) (PRODUCT C1 C1))");
    assertEquals(spreadsheet.getCellValue("A1"), 4.0);
    assertEquals(spreadsheet.getCellValue("A2"), 36.0);
  }

  @Test
  public void testDoubleValueToString() {
    DoubleValue d1 = new DoubleValue(12.0);
    DoubleValue d2 = new DoubleValue(67.0);
    assertEquals(d1.toString(), "12.0");
    assertEquals(d2.toString(), "67.0");
  }

  @Test
  public void testBooleanValueToString() {
    BooleanValue b1 = new BooleanValue(false);
    BooleanValue b2 = new BooleanValue(true);
    assertEquals(b1.toString(), "false");
    assertEquals(b2.toString(), "true");
  }

  @Test
  public void testStringValueToString() {
    StringValue s1 = new StringValue("blue");
    StringValue s2 = new StringValue("red");
    assertEquals(s1.toString(), "blue");
    assertEquals(s2.toString(), "red");
  }

  @Test
  public void testCyclesDirect() {
    spreadsheet.addCell("A1", "=A1");
    try {
      spreadsheet.getCellValue("A1");
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), "Cyclic references");
    }
  }

  @Test
  public void testCyclesIndirect() {
    spreadsheet.addCell("A1", "3");
    spreadsheet.addCell("B1", "4");
    spreadsheet.addCell("C1", "=D1");
    spreadsheet.addCell("D1", "=B2");
    spreadsheet.addCell("A2", "=(PRODUCT (SUM C1 A1) (SUM B1 D1))");
    spreadsheet.addCell("B2", "=(SUM C1 A1 B1)");
    try {
      spreadsheet.getCellValue("B2");
    } catch (IllegalStateException e) {
      assertEquals(e.getMessage(), "Cyclic references");
    }
  }

  @Test
  public void testRawValues() {
    spreadsheet.addCell("A1", "=(SUM (PRODUCT B1 C1) B1)");
    spreadsheet.addCell("B1", "test");
    spreadsheet.addCell("C1", 4);
    assertEquals(spreadsheet.getRawCellValue("A1"), "=(SUM (PRODUCT B1 C1) B1)");
    assertEquals(spreadsheet.getRawCellValue("B1"), "test");
    assertEquals(spreadsheet.getRawCellValue("C1"), "4");
  }

  @Test
  public void testLessThan() {
    spreadsheet.addCell("A1", 5);
    spreadsheet.addCell("B1", 3);
    spreadsheet.addCell("B2", 2);
    spreadsheet.addCell("A2", "=(< A1 B1)");
    spreadsheet.addCell("A3", "=(< B1 A1)");
    assertEquals(spreadsheet.getCellValue("A2"), false);
    assertEquals(spreadsheet.getCellValue("A3"), true);
  }

  @Test
  public void testLessThanInvalidType() {
    spreadsheet.addCell("A1", 6);
    spreadsheet.addCell("B1", true);
    spreadsheet.addCell("A2", "=(< A1 B1)");
    try {
      spreadsheet.getCellValue("A2");
    } catch (IllegalArgumentException e) {
      assertEquals(e.getMessage(), "Invalid Argument Type: only numbers");
    }
  }
}