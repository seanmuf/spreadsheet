package edu.cs3500.spreadsheets.view;

import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import edu.cs3500.spreadsheets.model.SheetBuilder;
import edu.cs3500.spreadsheets.model.WorksheetModel;
import edu.cs3500.spreadsheets.model.WorksheetReader;

import static org.junit.Assert.assertEquals;

/**
 * Test class for the WorksheetTextualView class.
 */
public class WorksheetTextualViewTest {

  @Test
  public void testTextualViewDisplaysCorrectlyNoErrors() {
    try {
      Readable readable1 = new BufferedReader(new FileReader("/Users/maxlincoln1/Desktop" +
              "/CS3500/Projects/HW05/resources/Test2"));
      WorksheetReader.WorksheetBuilder<WorksheetModel> builder1 = new SheetBuilder();
      WorksheetModel model1 = WorksheetReader.read(builder1, readable1);
      PrintWriter pw = new PrintWriter("/Users/maxlincoln1/Desktop/CS3500/Projects/HW05" +
              "/resources/Test2-Out");
      WorksheetView view = new WorksheetTextualView(model1, pw);
      view.display();
      pw.close();
      Readable readable2 = new BufferedReader(new FileReader("/Users/maxlincoln1/Desktop" +
              "/CS3500/Projects/HW05/resources/Test2-Out"));
      WorksheetReader.WorksheetBuilder<WorksheetModel> builder2 = new SheetBuilder();
      WorksheetModel model2 = WorksheetReader.read(builder2, readable2);
      assertEquals(model1.getRawCellValue("A1"), model2.getRawCellValue("A1"));
      assertEquals(model1.getRawCellValue("B1"), model2.getRawCellValue("B1"));
      assertEquals(model1.getRawCellValue("A2"), model2.getRawCellValue("A2"));
      assertEquals(model1.getRawCellValue("B2"), model2.getRawCellValue("B2"));
      assertEquals(model1.getRawCellValue("A3"), model2.getRawCellValue("A3"));
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  @Test
  public void testTextualViewDisplaysCorrectlyWithErrors() {
    try {
      Readable readable1 = new BufferedReader(new FileReader("/Users/maxlincoln1/Desktop" +
              "/CS3500/Projects/HW05/resources/Test3"));
      WorksheetReader.WorksheetBuilder<WorksheetModel> builder1 = new SheetBuilder();
      WorksheetModel model1 = WorksheetReader.read(builder1, readable1);
      PrintWriter pw = new PrintWriter("/Users/maxlincoln1/Desktop/CS3500/Projects/HW05" +
              "/resources/Test3-Out");
      WorksheetView view = new WorksheetTextualView(model1, pw);
      view.display();
      pw.close();
      Readable readable2 = new BufferedReader(new FileReader("/Users/maxlincoln1/Desktop" +
              "/CS3500/Projects/HW05/resources/Test3-Out"));
      WorksheetReader.WorksheetBuilder<WorksheetModel> builder2 = new SheetBuilder();
      WorksheetModel model2 = WorksheetReader.read(builder2, readable2);
      assertEquals(model1.getRawCellValue("B2"), model2.getRawCellValue("B2"));
      assertEquals(model1.getRawCellValue("B2"), "=(SUM C1 A1 B1)");
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  @Test
  public void testTextualViewUpdatesCorrectly() {
    try {
      Readable readable1 = new BufferedReader(new FileReader("/Users/maxlincoln1/Desktop" +
              "/CS3500/Projects/HW05/resources/Test2"));
      WorksheetReader.WorksheetBuilder<WorksheetModel> builder1 = new SheetBuilder();
      WorksheetModel model1 = WorksheetReader.read(builder1, readable1);
      PrintWriter pw = new PrintWriter("/Users/maxlincoln1/Desktop/CS3500/Projects/HW05" +
              "/resources/Test2-Out");
      WorksheetView view = new WorksheetTextualView(model1, pw);
      view.display();
      view.updateView("B5", "4");
      pw.close();
      Readable readable2 = new BufferedReader(new FileReader("/Users/maxlincoln1/Desktop" +
              "/CS3500/Projects/HW05/resources/Test2-Out"));
      WorksheetModel model2 = WorksheetReader.read(builder1, readable2);
      assertEquals(model2.getCellValue("B5"), 4.0);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}